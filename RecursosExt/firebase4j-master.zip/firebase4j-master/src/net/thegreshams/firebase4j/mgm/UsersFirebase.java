package net.thegreshams.firebase4j.mgm;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.LinkedHashMap;
import java.util.Map;

import net.thegreshams.firebase4j.error.FirebaseException;
import net.thegreshams.firebase4j.error.JacksonUtilityException;
import net.thegreshams.firebase4j.model.FirebaseResponse;
import net.thegreshams.firebase4j.model.UsuarioM;
import net.thegreshams.firebase4j.service.Firebase;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

// TODO: Auto-generated Javadoc
/**
 * The Class UsersFirebase.
 */
public class UsersFirebase {
	
	
	private static final String URL_DB = "http://gamma.firebase.com/username";
	private static final String KEY_DB = "tR7u9Sqt39qQauLzXmRycXag18Z2";

	
		/**
		 * Adds the usuario.
		 *
		 * @param usuariom the usuariom
		 */
		public static void addUsuario(UsuarioM usuariom) 
		{
			String nodo = "usuario" + usuariom.getId().toString(); 
		
			// get the base-url (ie: 'http://gamma.firebase.com/username')
			String firebase_baseUrl = URL_DB + nodo ;

			// get the api-key (ie: 'tR7u9Sqt39qQauLzXmRycXag18Z2')
			String firebase_apiKey = KEY_DB;

		 
			if( firebase_baseUrl == null || firebase_baseUrl.trim().isEmpty() ) {
				throw new IllegalArgumentException( "Program-argument 'baseUrl' not found but required" );
			}


			// create the firebase
			Firebase firebase = null;
			try {
				firebase = new Firebase( firebase_baseUrl );
			} catch (FirebaseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		// "DELETE" (the fb4jDemo-root)
		FirebaseResponse response = null;
		try {
			response = firebase.delete();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FirebaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			FirebaseResponse resp = firebase.get();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FirebaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		 

//		 "PUT" (test-map into the fb4jDemo-root)
		Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
 
 


		// "PUT" (test-map into a sub-node off of the fb4jDemo-root)
		dataMap = new LinkedHashMap<String, Object>();
		dataMap.put( "id", usuariom.getId().toString() );
		dataMap.put( "firstname", usuariom.getFirstname() );
		dataMap.put( "lastname", usuariom.getLastname() );
		dataMap.put( "telephone",usuariom.getTelephone() );
		dataMap.put( "city", usuariom.getCity() );
 
		try {
			response = firebase.put( dataMap );
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JacksonUtilityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FirebaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println( "\n\nResult of PUT (for the test-PUT):\n" + response );
		System.out.println("\n"); 
		
  
	}


     /**
      * Delete usuario.
      *
      * @param usuariom the usuariom 
      * 
      */
     public static void deleteUsuario(UsuarioM usuariom)  
     {

    	 String nodo = "usuario" + usuariom.getId().toString(); 
    	 // get the base-url (ie: 'http://gamma.firebase.com/username')
    	 // get the base-url (ie: 'http://gamma.firebase.com/username')
			String firebase_baseUrl = URL_DB + nodo ;

			// get the api-key (ie: 'tR7u9Sqt39qQauLzXmRycXag18Z2')
			String firebase_apiKey = KEY_DB;


	 
			if( firebase_baseUrl == null || firebase_baseUrl.trim().isEmpty() ) {
				throw new IllegalArgumentException( "Program-argument 'baseUrl' not found but required" );
			}


				// create the firebase
				Firebase firebase = null;
				try {
					firebase = new Firebase( firebase_baseUrl );
				} catch (FirebaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


				// "DELETE" (the fb4jDemo-root)
				FirebaseResponse response = null;
				try {
					response = firebase.delete();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FirebaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	
				try {
					FirebaseResponse resp = firebase.get();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FirebaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

 
				System.out.println( "\n\nResult of PUT (for the test-DELETE):\n" + response );
			//	response = firebase.delete( "entidad3");
				try {
					response = firebase.delete();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FirebaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println( "\n\nResult of DELETE (for the test-DELETE):\n" + response );
 

}
	
	
	
	
	
	

	 
	
}




